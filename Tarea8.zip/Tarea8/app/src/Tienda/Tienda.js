import Productos from '../Productos/Productos';
import Carrito from '../Carrito/Carrito';
import React, { useState } from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';

function Tienda() {
  const [selectedCategory, setSelectedCategory] = useState('');
  const [cart, setCart] = useState([]);
  const [total, setTotal] = useState(0);

  const addToCart = (product) => {
    const existingItem = cart.find((item) => item.id === product.id);
    if (existingItem) {
      existingItem.quantity += 1;
      setCart([...cart]);
    } else {
      const newProduct = { ...product, quantity: 1 };
      setCart([...cart, newProduct]);
    }

    setTotal(total + product.price);
  };

  const removeFromCart = (product) => {
    const existingItem = cart.find((item) => item.id === product.id);

    if (existingItem) {
      if (existingItem.quantity > 1) {
        existingItem.quantity -= 1;
      } else {
        const updatedCart = cart.filter((item) => item.id !== product.id);
        setCart(updatedCart);
      }
      setTotal(total - product.price);
    }
  };

  const products = [
    {
      id: 1,
      name: 'Árbol navideño',
      description: 'Arbol Verde 7 5P 2 28Mts 1310R Mix Wm N7',
      categorias: ['Navidad'],
      price: 100,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/400001-800-600?v=638308753290070000&width=800&height=600&aspect=true',
    },
    {
      id: 2,
      name: 'Esferas para árbol',
      description: 'Pequeños tesoros que iluminan tu árbol.',
      categorias: ['Navidad'],
      price: 2,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/394617-800-600?v=638297519060430000&width=800&height=600&aspect=true',
    },
    {
      id: 3,
      name: 'Tobogán Kidz Time',
      description: 'Este proporciona horas de entretenimiento.',
      categorias: ['Juguetes'],
      price: 60,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/304134-800-600?v=638001167192000000&width=800&height=600&aspect=true',
    },
    {
      id: 4,
      name: 'Scooter Rush 360',
      description: 'Este fabuloso y dinámico scooter esta diseñado para jóvenes de 8 años',
      categorias: ['Juguetes'],
      price: 100,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/254030-800-600?v=637830962017600000&width=800&height=600&aspect=true',
    },
    {
      id: 5,
      name: 'Balon Futbol Molten',
      description: 'Pelota Athletic Works  No 5 - Unidad',
      categorias: ['Deportes'],
      price: 40,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/368608-800-600?v=638206482661370000&width=800&height=600&aspect=true',
    },
    {
      id: 6,
      name: 'Botella Athletic Works ',
      description: 'Botella Athletic Works - 23 Oz',
      categorias: ['Deportes'],
      price: 10,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/348176-800-600?v=638145022202930000&width=800&height=600&aspect=true',
    }
    ,
    {
      id: 7,
      name: 'Tableta Panadol Ultra X',
      description: 'Alivio rápido de 5 tipos de dolor fuerte',
      categorias: ['Farmacia'],
      price: 3,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/349359-800-600?v=638152689701570000&width=800&height=600&aspect=true',
    }
    ,
    {
      id: 8,
      name: 'Aspirina Forte Caja X',
      description: 'Para el alivio sintomático de los dolores frecuentes',
      categorias: ['Farmacia'],
      price: 3.5,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/339854-800-600?v=638096854448770000&width=800&height=600&aspect=true',
    }
    ,
    {
      id: 9,
      name: 'Playera Wilson Polyspun',
      description: 'Ropa Deportiva suave al tacto,',
      categorias: ['Ropa'],
      price: 40,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/290052-800-600?v=637951486961200000&width=800&height=600&aspect=true',
    }
    ,
    {
      id: 10,
      name: 'Tshirt Fol',
      description: 'Tshirt Fol Cuello Red Cab Azul Osc M',
      categorias: ['Ropa'],
      price: 20,
      image: 'https://walmartgt.vtexassets.com/arquivos/ids/376677-800-600?v=638236066507270000&width=800&height=600&aspect=true',
    }
  ];

  const allCategories = [...new Set(products.flatMap((product) => product.categorias))];

  return (
    <div className="container">
    <br />
  <div>
    <select
      value={selectedCategory}
      onChange={(e) => setSelectedCategory(e.target.value)}
    >
      <option value="">Todos</option>
      {allCategories.map((category) => (
        <option key={category} value={category}>
          {category}
        </option>
      ))}
    </select>
  </div>
  <br />
  <br />
  <div>
    <div className="row">
      {products
        .filter((product) => {
          if (selectedCategory === '') {
            return true;
          }
          return product.categorias.includes(selectedCategory);
        })
        .map((product) => (
          <Productos
            key={product.id}
            {...product}
            onAddToCart={() => addToCart(product)}
          />
        ))}
    </div>
    <Carrito items={cart} total={total} onRemoveFromCart={removeFromCart} />
  </div>
</div>
  );
}

export default Tienda;