import Navbar from 'react-bootstrap/Navbar';

function Footer(){
    return(
        <Navbar fixed="bottom" >
            <p className='firma'>Julio Cesar Moreno Carranza 9490-17-675 --- Dostin Josue Morataya Alvarez 9490-18-1188</p>
        </Navbar>
    );
}

export default Footer;